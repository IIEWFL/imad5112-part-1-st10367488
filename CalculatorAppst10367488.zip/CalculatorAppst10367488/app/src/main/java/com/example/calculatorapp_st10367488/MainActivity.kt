package com.example.calculatorapp_st10367488

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {

    private var Digit1: TextView? = null
    private var Digit2: TextView? = null
    private var Result: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Digit1 = findViewById(R.id.Digit1)
        Digit2 = findViewById(R.id.Digit2)
        Result = findViewById(R.id.Result)

        val additionBtn = findViewById<Button>(R.id.additionBtn)
        val subtractionBtn = findViewById<Button>(R.id.subtractionBtn)
        val multiplicationBtn = findViewById<Button>(R.id.multiplicationBtn)
        val divisionBtn = findViewById<Button>(R.id.divisionBtn)


        additionBtn.setOnClickListener()
        {
            add()
        }
        subtractionBtn.setOnClickListener()
        {
            subtract()
        }
        multiplicationBtn.setOnClickListener()
        {
            multiply()
        }
        divisionBtn.setOnClickListener()
        {
            divide()
        }

    }

    @SuppressLint("SetTextI18n")
    private fun divide(){

        if (inputRequired() && notZero()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
           val answer = insert1.divide(insert2,2, RoundingMode.HALF_UP)
            Result?.text = "$insert1 / $insert2 = $answer"
        }
    }

    @SuppressLint("SetTextI18n")
    private fun notZero(): Boolean {

        var z = true

        val insert1 = Digit1?.text.toString().trim().toBigDecimal()
        val insert2 = Digit2?.text.toString().trim().toBigDecimal()

        if (insert1 == BigDecimal.ZERO || insert2 == BigDecimal.ZERO) {
            Result?.text = "Cannot divide by zero"
            z = false
        }
        return z
    }


    @SuppressLint("SetTextI18n")
    private fun add() {

        if (inputRequired()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
            val answer = insert1.add(insert2)
            Result?.text = "$insert1 + $insert2 = $answer"
        }

    }


    @SuppressLint("SetTextI18n")
    private fun subtract() {
        if (inputRequired()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
            val answer = insert1.subtract(insert2)
            Result?.text = "$insert1 - $insert2 = $answer"
        }

    }


    @SuppressLint("SetTextI18n")
    private fun multiply() {
        if (inputRequired()) {
            val insert1 = Digit1?.text.toString().trim().toBigDecimal()
            val insert2 = Digit2?.text.toString().trim().toBigDecimal()
            val answer = insert1.multiply(insert2)
            Result?.text = "$insert1 * $insert2 = $answer"
        }

    }


    private fun inputRequired(): Boolean {
        var b = true
        if (Digit1?.text.toString().trim().isEmpty()) {
            Digit1?.error = "please insert a number"
            b = false
        }
        if (Digit2?.text.toString().trim().isEmpty()) {
            Digit2?.error = "please insert a number"
            b = false
        }
        return b
    }

}


